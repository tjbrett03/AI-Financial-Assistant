"""
Contributors: Skylar Seguin, Thomas Brett-Labouchere, and Kevin Viren
Last modified: 3/6/2025
"""
import tkinter as tk
from tkinter import filedialog, messagebox
import openai
import os
from dotenv import load_dotenv

load_dotenv()
openai.api_key = "" #<--Either add API key here or make an environmental variable (env variable highly reccommended)<--

class SimpleUI(tk.Tk):
    def __init__(self):
        super().__init__()

        image = tk.PhotoImage(file="img/logo.png") # -KV
        self.iconphoto(False, image)
        
        self.title("Finance Tracker - Voyageur K&T")
        self.geometry("700x500") #Changed from 700x400 -KV
        self.configure(bg="#f0f0f0")

        self.chat_history = [] # -KV
        self.csv_data = "No CSV file has been uploaded yet." # -KV
        
        self.create_sidebar()
        self.create_dashboard_content()

    def create_sidebar(self):
        sidebar = tk.Frame(self, bg="#180D04", width=150, height=500)
        sidebar.pack(side="left", fill="y")

        dash_btn = tk.Button(sidebar, text="File Analysis", command=self.show_dashboard, 
                             bg="#804515", fg="white", font=("Arial", 13, "bold"), 
                             relief="flat", padx=10, pady=10, width=15)
        dash_btn.pack(pady=10)

        chatbot_btn = tk.Button(sidebar, text="ChatBot", command=self.show_chatbot,
                                bg="#804515", fg="white", font=("Arial", 13, "bold"),
                                relief="flat", padx=10, pady=10, width=15)
        chatbot_btn.pack(pady=10)

        exit_btn = tk.Button(sidebar, text="Exit", command=self.destroy, #Changed self.quit to self.destroy to properly stop application - KV
                             bg="#A64B00", fg="white", font=("Arial", 13, "bold"),
                             relief="flat", padx=10, pady=10, width=15)
        exit_btn.pack(pady=10)

    def create_dashboard_content(self):
        self.main_frame = tk.Frame(self, bg="#f0f0f0", width=450, height=500)
        self.main_frame.pack(side="right", fill="both", expand=True)

        self.title_label = tk.Label(self.main_frame, text="File Analysis", 
                                    font=("Arial", 20, "bold"), bg="#f0f0f0", fg="#333")
        self.title_label.pack(pady=10)

        db_input_frame = tk.Frame(self.main_frame, bg="white", bd=2, relief="groove") #changed input_frame to db_input_frame 
        db_input_frame.pack(pady=10, padx=20, fill="x")                               #for "dashboard input frame" - KV

        self.input_label = tk.Label(db_input_frame, text="Enter CSV file for AI assistance",
                                    font=("Arial", 14), bg="white", fg="#555")
        self.input_label.pack(pady=5)

        self.file_entry = tk.Entry(db_input_frame, font=("Arial", 12), state=tk.DISABLED)
        self.file_entry.pack(side="left", pady=5, padx=10, fill="x", expand=True)

        browse_btn = tk.Button(db_input_frame, text="Browse", command=self.load_csv, 
                               bg="#652E00", fg="white", font=("Arial", 10, "bold"), 
                               relief="flat", padx=10, pady=5)
        browse_btn.pack(pady=5, padx=5, side="right")

        self.output_label = tk.Label(self.main_frame, text="AI Output", font=("Arial", 14), bg="#f0f0f0", fg="#555")
        self.output_label.pack(pady=10)


        db_output_frame = tk.Frame(self.main_frame) #added frame to hold text and scrollbar widgets -KV
        db_output_frame.pack(pady=5, padx=20, fill="both", expand=True)

        self.output_text = tk.Text(db_output_frame, height=10, width=48, font=("Arial", 12), wrap="word", state=tk.DISABLED)
        db_scrollbar = tk.Scrollbar(db_output_frame, command=self.output_text.yview) #Added scrollbar -KV
        self.output_text.config(yscrollcommand=db_scrollbar.set)


        
        self.output_text.pack(side="left", fill="both", expand=True)
        db_scrollbar.pack(side="right", fill="y")

        clear_btn = tk.Button(self.main_frame, text="Clear", command=self.clear_all,
                              bg="#652E00", fg="white", font=("Arial", 10, "bold"),
                              relief="flat", padx=10, pady=5)
        clear_btn.pack(pady=5)

    def create_chatbot_content(self):
        self.chatbot_frame = tk.Frame(self, bg="#f0f0f0", width=450, height=500)
        self.chatbot_frame.pack(side="right", fill="both", expand=True)

        self.chatbot_title_label = tk.Label(self.chatbot_frame, text="ChatBot", 
                                            font=("Arial", 20, "bold"), bg="#f0f0f0", fg="#333")
        self.chatbot_title_label.pack(pady=10)

        cb_input_frame = tk.Frame(self.chatbot_frame, bg="white", bd=2, relief="groove") #added cb_input_frame to add a border 
        cb_input_frame.pack(pady=10, padx=20, fill="x")                               #like is used in the File Analysis page - KV

        self.chatbot_input_label = tk.Label(cb_input_frame, text="Your Message", 
                                            font=("Arial", 14), bg="white", fg="#555")
        self.chatbot_input_label.pack(pady=5)

        self.chatbot_input_entry = tk.Entry(cb_input_frame, font=("Arial", 12))
        self.chatbot_input_entry.pack(side="left", pady=5, padx=10, fill="x", expand=True)

        send_btn = tk.Button(cb_input_frame, text="Send", command=self.send_message_to_chatbot, 
                             bg="#652E00", fg="white", font=("Arial", 10, "bold"), 
                             relief="flat", padx=10, pady=5)
        send_btn.pack(side="right", pady=5, padx=5)

        
        self.chatbot_output_label = tk.Label(self.chatbot_frame, text="Chat History", 
                                             font=("Arial", 14), bg="#f0f0f0", fg="#555")
        self.chatbot_output_label.pack(pady=5)


        cb_output_frame = tk.Frame(self.chatbot_frame) #added frame to hold text and scrollbar widgets -KV
        cb_output_frame.pack(pady=5, padx=20, fill="both", expand=True)
        

        self.chatbot_output_text = tk.Text(cb_output_frame, height=12, width=48, font=("Arial", 12), wrap="word", state=tk.DISABLED)
        cb_scrollbar = tk.Scrollbar(cb_output_frame, command=self.chatbot_output_text.yview) #Added scrollbar -KV
        self.chatbot_output_text.config(yscrollcommand=cb_scrollbar.set)
        
        self.chatbot_output_text.pack(side="left", fill="both", expand=True)
        cb_scrollbar.pack(side="right", fill="y")

    def clear_all(self):
        self.csv_data = "No CSV file has been uploaded yet." # -KV
        self.chat_history = [] # -KV
        self.file_entry.config(state=tk.NORMAL) 
        self.output_text.config(state=tk.NORMAL) 
        self.file_entry.delete(0, tk.END)
        self.output_text.delete("1.0", tk.END)
        self.file_entry.config(state=tk.DISABLED) 
        self.output_text.config(state=tk.DISABLED) 

    def load_csv(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
        if file_path:
            self.file_entry.config(state=tk.NORMAL) 
            self.file_entry.delete(0, tk.END)
            self.file_entry.insert(0, file_path)
            self.file_entry.config(state=tk.DISABLED) 

            self.process_csv(file_path)

    def process_csv(self, file_path):
        try:
            with open(file_path, "r") as file:
                self.csv_data = file.read() # -KV

            ai_response = self.get_ai_response(self.csv_data) #(csv_data)

            self.output_text.config(state=tk.NORMAL) 
            self.output_text.delete("1.0", tk.END)
            self.output_text.insert(tk.END, ai_response)
            self.output_text.config(state=tk.DISABLED) 

        except Exception as e:
            messagebox.showerror("Error", f"Failed to read file: {e}")

    def get_ai_response(self, csv_data):
        try:
            if not openai.api_key:
                return "Error: OpenAI API key is missing."

            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": f"Analyze this CSV data:\n{csv_data}"}] 
            )
            output_text = response["choices"][0]["message"]["content"]
            return output_text
        
        except Exception as e:
            return f"Error occurred while processing the file: {str(e)}"

    def send_message_to_chatbot(self):
        user_input = self.chatbot_input_entry.get()
        if user_input.strip():
          
            self.chatbot_output_text.config(state=tk.NORMAL)  
            self.chatbot_output_text.insert(tk.END, f"User: {user_input}\n")
            self.chatbot_output_text.config(state=tk.DISABLED)  


            self.chat_history.append({"role": "user", "content": user_input}) # -KV
            chatbot_response = self.get_chatbot_response()  # -KV
            
            self.chatbot_output_text.config(state=tk.NORMAL)
            self.chatbot_output_text.insert(tk.END, f"Bot: {chatbot_response}\n\n")
            self.chatbot_output_text.config(state=tk.DISABLED)

            self.chatbot_input_entry.delete(0, tk.END)

    def get_chatbot_response(self): #(self, user_input) -KV
        try:
            if not openai.api_key:
                return "Error: OpenAI API key is missing."

            # Ensure CSV data is available
            csv_context = self.csv_data # -KV
            
            self.chat_history.insert(0, {"role": "system", "content": f"This is the CSV data for reference:\n{csv_context}"})

            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=self.chat_history # -KV
            )
            
            bot_reply = response["choices"][0]["message"]["content"] # -KV
            self.chat_history.append({"role": "assistant", "content": bot_reply}) # -KV
            return bot_reply # -KV
        
        except Exception as e:
            return f"Error occurred while processing the message: {str(e)}"

    def show_dashboard(self):
        self.title_label.config(text="File Analysis") #Changed text from "Dashboard to File Analysis -KV
        self.input_label.config(text="Enter CSV file for AI assistance")

        if hasattr(self, 'chatbot_frame'):  # Check if chatbot_frame already exists -KV
            self.chatbot_frame.pack_forget()
        self.main_frame.pack(side="right", fill="both", expand=True)

    def show_chatbot(self):
        self.main_frame.pack_forget()
        
        if not hasattr(self, 'chatbot_frame'):  # Check if chatbot_frame already exists -KV
            self.create_chatbot_content()
        self.chatbot_frame.pack(side="right", fill="both", expand=True)

if __name__ == "__main__":
    app = SimpleUI()
    app.mainloop()
